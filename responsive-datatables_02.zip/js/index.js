$(document).ready(function() {
    $('.ai_datatables').DataTable({
      responsive: true,
      fixedHeader: true,
      scrollY: 300,
      scroller: {
            loadingIndicator: true
        },
      keys: true,
      dom: '<<"padding-right-5px"l>Bfrtip>',
      buttons: [
        'copy', 'excel', 'pdf', 'print', 'csv'
      ]
    });
} );