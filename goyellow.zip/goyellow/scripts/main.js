$(window).load(function() {
	$("#preload").click(function() {
	$("#preload").fadeOut(1200);
});
});