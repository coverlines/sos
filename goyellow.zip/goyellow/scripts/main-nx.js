$("#main").hide();
$(window).load(function() {
	$("#preload")/*.delay(100)*/.fadeOut(2000);
	//$("#preload").click(function() {
	//$("#preload").fadeOut(1200);
	//$('body').css('overflow-style','panner');
});
	
//});