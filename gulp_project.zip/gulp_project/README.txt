1. NPM installieren

2. Projektordner anlegen.

3. In CMD --> 'npm init' // package.json wird erzeugt

4. In CMD --> 'npm install gulp --save-dev',
	sowie weitere Gulp-Plugins z.B.

	...npm install --save-dev gulp-concat
	...npm install --save-dev gulp-uglify
	...npm install --save-dev gulp-autoprefixer