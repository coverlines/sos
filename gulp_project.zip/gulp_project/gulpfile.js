var gulp = require('gulp'),
	concat = require('gulp-concat'),
	uglyfly = require('gulp-uglyfly'),
	autoprefixer = require('gulp-autoprefixer');

gulp.task('scripts', function() {
  return gulp.src('src/js/*.js')
    .pipe(concat('main.js'))
    /*.pipe(uglyfly()) // minimiert JS*/
    .pipe(gulp.dest('./dist/'));
});
