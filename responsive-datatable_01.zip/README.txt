A Pen created at CodePen.io. You can find this one at https://codepen.io/bruce0205/pen/mXZXzN.

 