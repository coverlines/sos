A Pen created at CodePen.io. You can find this one at https://codepen.io/RedJokingInn/pen/mRQqda.

 Example of the fixed header extension and a demo of all elements (buttons, filter, info and length) on the same line.