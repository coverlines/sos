//alert ('HALLO from main.js');
// ................................... 
// 
// ................................... FORM NAVIGATION
var current_form = 1; // 1-5




// Month here is 1-indexed (January is 1, February is 2, etc). This is
// because we're using 0 as the day so that it returns the last day
// of the last month, so you have to add 1 to the month number 
// so it returns the correct amount of days
function daysInMonth (month, year) {
    return new Date(year, month, 0).getDate();
}

//console.log(daysInMonth(2,2018)); // 31

var TodayDate = new Date();
var d = TodayDate.getDate();
var m = TodayDate.getMonth()+1;
var y = TodayDate.getFullYear();

//console.log(d);
//console.log(m);
//console.log(y);