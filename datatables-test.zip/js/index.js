	$(document).ready(function() {

//*
		$('#makeDataTable').dataTable({"responsive":true});
//*/





/*
		$('#dt_basic_[ModuleID,System]').dataTable({
			"responsive":true,
			"order": [[ 0, "desc" ]],
			"sDom": "<'dt-toolbar'<'col-xs-12 col-sm-6'f><'col-sm-6 col-xs-12 hidden-xs'l>r>"+
				"t"+
				"<'dt-toolbar-footer'<'col-sm-6 col-xs-12 hidden-xs'i><'col-xs-12 col-sm-6'p>>",
			//"autoWidth" : true,
			"oLanguage": {
				"sSearch": '<span class="input-group-addon"><i class="glyphicon glyphicon-search"></i></span>'
			}
		});
//*/







				/* BASIC ;*/
/*
					var responsiveHelper_dt_basic_[ModuleID,System] = undefined;
					var responsiveHelper_datatable_fixed_column = undefined;
					var responsiveHelper_datatable_col_reorder = undefined;
					var responsiveHelper_datatable_tabletools = undefined;
					
					var breakpointDefinition = {
						tablet : 1024,
						phone : 480
					};
					
					$('#dt_basic_[ModuleID,System]').removeClass( 'display' ).addClass('table table-striped table-bordered');
					$('#dt_basic_[ModuleID,System]').dataTable({
						"order": [[ 0, "desc" ]],
						"sDom": "<'dt-toolbar'<'col-xs-12 col-sm-6'f><'col-sm-6 col-xs-12 hidden-xs'l>r>"+
							"t"+
							"<'dt-toolbar-footer'<'col-sm-6 col-xs-12 hidden-xs'i><'col-xs-12 col-sm-6'p>>",
						"autoWidth" : true,
				        "oLanguage": {
						    "sSearch": '<span class="input-group-addon"><i class="glyphicon glyphicon-search"></i></span>'
						},
						"preDrawCallback" : function() {
							// Initialize the responsive datatables helper once.
							if (!responsiveHelper_dt_basic_[ModuleID,System]) {
								responsiveHelper_dt_basic_[ModuleID,System] = new ResponsiveDatatablesHelper($('#dt_basic_[ModuleID,System]'), breakpointDefinition);
							}
						},
						"rowCallback" : function(nRow) {
							responsiveHelper_dt_basic_[ModuleID,System].createExpandIcon(nRow);
						},
						"drawCallback" : function(oSettings) {
							responsiveHelper_dt_basic_[ModuleID,System].respond();
						}
					});
//*/
				/* END BASIC */
	});